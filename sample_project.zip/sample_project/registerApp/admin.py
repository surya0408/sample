from django.contrib import admin
from registerApp.models import UserModel
# Register your models here.
admin.site.register(UserModel)